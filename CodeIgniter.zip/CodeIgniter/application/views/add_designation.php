<?php $this->load->view( 'header' ) ?>

<main role = 'main' class = 'col-md-9 ml-sm-auto col-lg-10 px-4'>
<h1 class = 'h2'>Add Designation</h1>
<form method = 'post'>

<label>Department Name</label>
<select  name ='department_name'>
<?php 

foreach($result as $row)
{ 
  echo '<option value="'.$row->department_name.'">'.$row->department_name.'</option>';
}
?>
<!-- <option value = '' selected>--Select--</option>
<?php //foreach ( $result as $row=> $value ) {
    ?>
    <option value = "<?php //echo $value['department_name'] ; ?>" <?php echo set_select( 'department_name', $value[ 'idepartment_named' ]);
    ?> ><?php //echo $value[ 'department_name' ] ;
    ?> </option>
    <?php //}
    ?> -->
    </select><br><br>

    <label>Designation</label>
    <input type = 'text'  name = 'designation' placeholder = 'Designation'><br><br>
    <button type = 'submit' class = 'btn btn-primary'>Submit</button>
    </form>
    </main>