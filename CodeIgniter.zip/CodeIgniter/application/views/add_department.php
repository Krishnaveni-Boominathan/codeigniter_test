<?php $this->load->view('header') ?>


<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <h1 class="h2">Add Department</h1>
    <form method="post" action="<?php echo base_url() ?>index.php/payroll/do_insert">
       
            <label>Department Name</label>
            <input type="text"  name="dept_name" placeholder="Department Name">
      
       
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</main>
