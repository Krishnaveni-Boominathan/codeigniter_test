<?php
defined( 'BASEPATH' ) or exit( 'No direct script access allowed' );


class Designation extends CI_Controller
 {
    public function index()
 {
        $query = $this->db->query( 'SELECT * FROM `designation`' );
        $data[ 'result' ] = $query->result_array();
        $this->load->view( 'view_designation', $data );

    }


    public function add_designation()
    {
        $query = $this->db->query( 'SELECT * FROM `department`' );
        $data['result']= $query->result_array();
           $this->load->view( 'add_designation',$data);
       }
   
       public function insert()
       {
              $dept_name = $_POST[ 'department' ];
              $desg_name = $_POST[ 'designation' ];
              $query = $this->db->query( "INSERT INTO `designation`(`department_name`,`designation_name`)
                   VALUES ('$dept_name','$desg_name')" );
              if ( $query ) {
                  $this->session->set_flashdata( 'inserted', 'yes' );
                  redirect( 'designation' );
              } else {
                  $this->session->set_flashdata( 'inserted', 'no' );
                  redirect( 'designation' );
              }
      
          }



    public function editdesg( $id )
 {
 
        $query = $this->db->query( "SELECT * FROM `designation` WHERE `id`='$id'" );
        $data[ 'result' ] = $query->result_array();
        $data[ 'id' ] = $id;
        $this->load->view( 'edit_designation', $data );

    }

    public function editdesg_post()
 {

    $dept_name = $_POST[ 'department_name' ];
    $desg_name = $_POST[ 'des_name' ];
        $id = $_POST[ 'id' ];
        $query = $this->db->query( "UPDATE `designation` SET `department_name`='$dept_name'AND `designation_name`='$desg_name' WHERE `id`='$id'" );
        if ( $query ) {
            $this->session->set_flashdata( 'updated', 'yes' );
            redirect( 'designation' );
        } else {
            $this->session->set_flashdata( 'updated', 'no' );
            redirect( 'designation' );
        }
    }

    public function deletedesg()
 {
        print_r( $_POST );

        $delete_id = $_POST[ 'delete_id' ];
        $query = $this->db->query( "DELETE FROM `designation` WHERE  `id`='$delete_id'" );
        if ( $query ) {
            echo 'deleted';
        } else {
            echo 'notdeleted';
        }
    }

    public function active_status_user($id){
        if($status == '1') {
                  $data = array('status' => '0');
                  $this->db->where('id', $id);
                  $result = $this->db->update('designation',$data);
                  redirect('payroll');
              } else {
                  $data = array('status' => '1');
                  $this->db->where('id',$id);
                  $result = $this->db->update('designation',$data);
                  redirect('payroll');
              }
            }
          
}
?>