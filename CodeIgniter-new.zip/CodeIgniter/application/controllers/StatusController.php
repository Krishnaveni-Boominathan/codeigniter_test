<?php 

class StatusController extends CI_Controller
{
public function index(){
	$data['result'] = $this->db->get('department')->result_array();
	$this->load->view('viewdept',$data);
}


      public function active_status_user($id){
        if($status == '1') {
                  $data = array('status' => '0');
                  $this->db->where('id', $id);
                  $result = $this->db->update('department',$data);
                  redirect('payroll');
              } else {
                  $data = array('status' => '1');
                  $this->db->where('id',$id);
                  $result = $this->db->update('department',$data);
                  redirect('payroll');
              }
            }
          }

?>