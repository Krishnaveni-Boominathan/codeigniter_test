<?php
defined('BASEPATH') OR exit('No direct script access allowed'); //cannot access any class directly by main path 
class employee extends CI_Controller{
    public function __construct(){
        parent::__construct();
        $this->load->model('Employee_model');
    }
     public function index(){
        $query = $this->db->query( 'SELECT * FROM `employee`' );
        $data[ 'result' ] = $query->result_array();
       $this->load->view('view_employee',$data);
     }
     public function create(){
      $this->load->model('Department_model');
      $this->load->model('Designation_model');
      $data['departments'] = $this->Department_model->get_departments();
      $data['designations'] = $this->Designation_model->get_designations();
      
       $this->load->view('employee',$data);
        // $this->load->view('employee');
     }

     public function store(){
        $data = array(
            "employee_name" => $this->input->post('emp_name'),
            "salary" => $this->input->post('salary'),
            "date_of_joining" => $this->input->post('doj'),
            "department_name" => $this->input->post('department'),
            "designation_name" => $this->input->post('designation')
        );

        $this->Employee_model->insert($data);
       
        redirect(base_url('index.php/employee'));
     }

     public function edit($id){
        $data['data']=$this->Employee_model->find_record_by_id($id);
        $this->load->view('update_employee',$data);
     }
     public function update($id){
        $data1 = array(
            "employee_name" => $this->input->post('emp_name'),
            "salary" => $this->input->post('salary'),
            "date_of_joining" => $this->input->post('doj'), "department_name" => $this->input->post('department'),
            "designation_name" => $this->input->post('designation')
        );

        $this->Employee_model->update($data1, $id);
       
        redirect(base_url('index.php/employee'));
     }
     public function delete($id){
        $this->Employee_model->delete($id);
       
        redirect(base_url('index.php/employee'));
     }
     public function active_status_user($id){
      if($status == '1') {
                $data = array('status' => '0');
                $this->db->where('id', $id);
                $result = $this->db->update('designation',$data);
                redirect('payroll');
            } else {
                $data = array('status' => '1');
                $this->db->where('id',$id);
                $result = $this->db->update('designation',$data);
                redirect('payroll');
            }
          }
          
     
        
}
?>