<?php $this->load->view('header') ?>


<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <h1 class="h2">Edit Blog</h1>
    <a href="<?php echo base_url('index.php/payroll'); ?>">Back</a>
    <form id="editForm" method="post" action="<?php echo base_url() ?>index.php/designation/editdesg_post">
    <input type="hidden" name="id" value="<?php echo $id ?>">
    <label for="department">Choose a department:</label>
<select name="department_name" id="department">
<option value="" selected>Select</option>
<?php foreach ($result as $row => $value): ?>

  <option value="<?php echo $value['department_name'] ?>">
<?php echo $value['department_name'] ?></option>
<?php endforeach; ?>
</select>       
    <label>Designation Name</label>
            <input type="text"  name="des_name" value="<?php echo $result[0]['designation_name'] ?>">
      
       
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
	<script>
		$("#editForm").submit(function (event) {
			event.preventDefault();
			$.ajax({
				url: "<?php echo base_url('index.php/designation/editdesg_post'); ?>",
				data: $("#editForm").serialize(),
				type: "post",
				success: function (data) {
					alert('Successfully updated');
					window.location.href = '<?php echo base_url("index.php/payroll"); ?>';
				},
				error: function () {
					alert("error");
				}
			});
		});
	</script>

      