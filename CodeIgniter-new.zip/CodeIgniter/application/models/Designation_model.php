<?php
class Designation_model extends CI_Model {

public function __construct() {
    parent::__construct();
}

public function get_designations() {
    
    $query = $this->db->get('designation');
    return $query->result();
}
public function get_designations_by_department($department) {
   
    $this->db->where('department_name', $department);
    $query = $this->db->get('designation');  
    return $query->result();
 }
 
}
?>
